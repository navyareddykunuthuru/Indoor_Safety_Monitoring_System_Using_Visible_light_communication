from vpython import *
from time import sleep  # For timed intervals
from bulb_rays import BulbRays
from time import time
from random import uniform
import vlc_protocol
from threading import Thread

# Create the canvas with a diagonal view
canvas = canvas(width=800, height=600, background=color.white, title="Room Simulation")
canvas.camera.pos = vector(5, 5, 15)
canvas.camera.axis = vector(-5, -5, -15)

# Define a bigger room (walls, floor, ceiling)
floor = box(pos=vector(0, -0.05, 0), size=vector(15, 0.1, 15), color=color.gray(0.5))
left_wall = box(pos=vector(-7.5, 2.5, 0), size=vector(0.1, 5, 15), color=color.blue)
right_wall = box(pos=vector(7.5, 2.5, 0), size=vector(0.1, 5, 15), color=color.red)
back_wall = box(pos=vector(0, 2.5, -7.5), size=vector(15, 5, 0.1), color=color.green)

# Add objects in the room
# Refrigerator
refrigerator = box(pos=vector(-6, 1, 6), size=vector(1, 2, 1), color=color.cyan)

# Microwave
microwave = box(pos=vector(-4, 1, 6), size=vector(1.2, 0.8, 1), color=color.yellow)

# Timer variables
microwave_timer = 60  # Start time in seconds
microwave_on = False  # Track whether the microwave is on
timer_done_label = None  # To hold the "Timer Done" label
show_timer_done = False  # Track whether the label is visible
timer_start_time = 0  # For tracking time elapsed

# Timer label for displaying countdown
timer_label = label(pos=vector(4, 2.5, 1), text='', visible=False)

# Function to toggle the microwave on/off
def toggle_microwave(evt):
    global microwave_on, microwave_timer, timer_done_label, timer_start_time, show_timer_done
    if microwave_on:  # Turn off
        microwave_on = False
        timer_label.visible = False  # Hide the timer
        if timer_done_label:
            timer_done_label.visible = False  # Hide "Timer Done" if still visible
    else:  # Turn on
        microwave_on = True
        microwave_timer = 60  # Reset timer to 60 seconds
        timer_label.visible = True
        timer_done_label = None  # Reset the "Timer Done" label
        show_timer_done = False
        timer_start_time = time()  # Record the start time

# Microwave button
microwave_button = button(bind=toggle_microwave, text="Microwave Off", background=color.red)


# Simulation loop for microwave
def microwave_simulation():
    try:
        global microwave_timer, microwave_on, timer_done_label, show_timer_done, timer_start_time

        print("kill")
        # Handle microwave countdown when it's on
        if microwave_on:
            print("onnnn")
            elapsed_time = time() - timer_start_time
            microwave_timer = max(0, 60 - int(elapsed_time))  # Update the timer

            timer_label.text = f"Time Left: {microwave_timer} sec"

            if microwave_timer == 0 and not show_timer_done:
                # Timer has completed
                timer_done_label = label(pos=vector(4, 3, 1), text="Timer Done", height=16, color=color.red)
                show_timer_done = True
                timer_start_time = time()  # Reset start time for hiding label after 1 minute

            if show_timer_done and time() - timer_start_time >= 60:  # Hide "Timer Done" after 1 minute
                timer_done_label.visible = False
                show_timer_done = False
        else:
            microwave_button.text = "Microwave Off"
            microwave_button.background = color.red
        microwave_button.text = "Microwave On" if microwave_on else "Microwave Off"
        microwave_button.background = color.green if microwave_on else color.red

    except Exception as e:
        print(f"erorrr {e}")
# Bulb
bulb = sphere(pos=vector(0, 4.5, 0), radius=0.3, color=color.white, emissive=True)


# TV
tv = box(pos=vector(5, 2.5, -7.3), size=vector(3, 2, 0.1), color=color.black)
# Initial state of the TV
tv_powered_on = False  # Track the state of the TV
tv_on_time = 0  # Store the time when the TV was turned on
tv_off_time = 0  # Store the time when the TV was turned off
power_consumption_rate = 100  # Power consumption rate in watts (example)

# Label to display TV status and power consumption
tv_info_label = label(text='TV Info', pos=vector(5, 4.5, -7.3), height=40, visible=False)

# Function to calculate power consumption
def calculate_tv_power_consumption():
    if tv_powered_on:
        # Calculate power consumption based on time the TV has been on
        time_on = time() - tv_on_time
        power_consumed = (time_on / 3600) * power_consumption_rate  # Power consumption in Wh
        return power_consumed
    return 0

# Function to update TV information (status, power consumption, time on)
def update_tv_info():
    if tv_powered_on:
        time_on = (time() - tv_on_time) / 3600  # Time in hours
        tv_info_label.text = f"TV Status: On\nPower Consumption: {calculate_tv_power_consumption():.2f} Wh\nTime On: {time_on:.2f} hours"
    else:
        tv_info_label.text = "TV Status: Off\nPower Consumption: 0.00 Wh\nTime On: 0.00 hours"
# Define a list to hold light rays
light_rays = []
# Function to change the TV color when the button is pressed
def toggle_tv_color(evt):
    global tv, tv_powered_on, light_rays
    if tv.color == color.black:  # If TV is off (black)
        tv.color = color.white    # Turn the TV on (white)
        tv_toggle_btn.text = 'Turn Off'
        tv_toggle_btn.background = color.green
        tv_powered_on = True
        tv_on_time = time()  # Record the time when the TV was turned on
        tv_info_label.visible = True  # Show TV info when TV is on
    else:  # If TV is on (white)
        tv.color = color.black    # Turn the TV off (black)
        tv_toggle_btn.text = 'Turn On'
        tv_toggle_btn.background = color.red
        tv_powered_on = False
        tv_off_time = time()  # Record the time when the TV was turned off
        tv_info_label.visible = False  # Hide TV info when TV is off

    update_tv_info()  # Update the displayed information


# Create a button that triggers the toggle_tv_color function when clicked
tv_toggle_btn = button(bind=toggle_tv_color, text='Turn On', background=color.red)

table = box(pos=vector(-6, 0.5, 1), size=vector(3, 0.2, 2), color=color.purple)
stove = box(pos=vector(-6, 1, 1), size=vector(1, 0.4, 1), color=color.red)
flame = cone(pos=vector(-6, 1.2, 1), axis=vector(0, 0.5, 0), radius=0.5, color=color.orange, emissive=True)

# Initialize flame parameters
flame_intensity = 0.0
intensity_threshold = 0.8  # Set your threshold here
flame_visible = False  # Track if the flame is visible
flame_light_path = None  # Variable to hold the light path object

# Create a label to display flame intensity
flame_info_label = label(text='Flame Intensity Info', pos=vector(-6, 3, 1), height=40, visible=False)

# Function to update flame intensity
def update_flame_intensity():
    global flame_intensity
    if flame_visible:
        flame_intensity = uniform(0.1, 1.0)  # Random intensity between 0.1 and 1.0
        if flame_intensity > intensity_threshold:
            flame_info_label.text = f"Flame Intensity: {flame_intensity:.2f} (Threshold Exceeded!)"
            flame_info_label.color = color.red
        else:
            flame_info_label.text = f"Flame Intensity: {flame_intensity:.2f}"
            flame_info_label.color = color.white

# Function to toggle flame visibility
def toggle_flame(evt):
    global flame, flame_visible, flame_light_path
    if not flame_visible:  # Turn the flame on
        flame.visible = True
        flame_control_btn.text = 'Turn Flame Off'
        flame_control_btn.background = color.green
        flame_info_label.visible = True
        flame_visible = True

        # Create a light path from the flame to a target (e.g., transceiver)
        flame_light_path = cylinder(pos=flame.pos, axis=transceiver.pos - flame.pos, radius=0.02, color=color.orange)

    else:  # Turn the flame off
        flame.visible = False
        flame_control_btn.text = 'Turn Flame On'
        flame_control_btn.background = color.red
        flame_info_label.visible = False
        flame_visible = False

        # Remove the light path
        if flame_light_path:
            flame_light_path.visible = False
            flame_light_path = None

# Flame intensity updater (use this in your simulation loop)
def flame_simulation_loop():
    while True:
        rate(10)  # 10 updates per second
        if flame_visible:
            update_flame_intensity()

# Create a button to control the flame
flame_control_btn = button(bind=toggle_flame, text='Turn Flame On', background=color.red)


# Device that transmits and receives light
transceiver = sphere(pos=vector(0, 1, 0), radius=0.5, color=color.magenta, emissive=True)

# Labels for the objects
label_refrigerator = label(pos=refrigerator.pos + vector(0, 1.2, 0), text="Refrigerator", box=False, color=color.black)
label_microwave = label(pos=microwave.pos + vector(0, 1, 0), text="Microwave", box=False, color=color.black)
label_bulb = label(pos=bulb.pos + vector(0, 0.5, 0), text="Bulb", box=False, color=color.black)
label_tv = label(pos=tv.pos + vector(0, 1.2, 0), text="TV", box=False, color=color.black)
label_transceiver = label(pos=transceiver.pos + vector(0, 0.8, 0), text="Transceiver", box=False, color=color.black)
label_stove = label(pos=stove.pos + vector(0, 0.8, 0), text="Gas Stove", box=False, color=color.black)

# Initialize BulbRays
bulb_rays = BulbRays(bulb=bulb, receiver=transceiver)

# Function to cycle through bulb colors
def change_bulb_color():
    while True:
        for c in bulb_rays.ray_colors:
            bulb.color = c

            sleep(1)  # Wait before changing color

# Intensity Control
def adjust_intensity(evt):
    if evt.key == 'up':
        bulb_rays.set_intensity(bulb_rays.intensity + 0.1)  # Increase intensity
    elif evt.key == 'down':
        bulb_rays.set_intensity(bulb_rays.intensity - 0.1)  # Decrease intensity

scene.bind('keydown', adjust_intensity)  # Bind arrow keys for intensity adjustment

# Function to simulate VLC communication (data transmission via light)
def simulate_vlc_transmission():
    """
    This function simulates the transmission of bulb information via light signals.
    You can enhance this to transmit data to a receiver or log it.
    """
    print(f"Transmitting Data via Light: Color = {bulb.color}, Intensity = {bulb_rays.intensity:.2f}, Power Consumption = {calculate_power_consumption():.2f} W")
    # You can implement further functionality here to simulate actual light data transmission.

def calculate_power_consumption():
    """
    Calculates the power consumption of the bulb based on its intensity.
    This is a basic model where power is proportional to intensity.
    Adjust the constants (e.g., max power) based on your bulb specifications.
    """
    max_power = 10.0  # Maximum power in watts (this is an arbitrary value, adjust as needed)
    power_consumption = max_power * bulb_rays.intensity  # Power is proportional to intensity
    return power_consumption
# Function to update the bulb's information and simulate VLC communication
def update_bulb_info():
    bulb_info_label.text = f"Bulb Color: {str(bulb.color)}\n" + \
                            f"Intensity: {bulb_rays.intensity:.2f}\n" + \
                            f"Power Consumption: {calculate_power_consumption():.2f} W"

# Button to toggle light rays
def toggle_rays():
    if bulb_toggle_btn.text == 'Show Rays':
        bulb_toggle_btn.text = 'Stop Rays'
        bulb_toggle_btn.background = color.green
        emit_rays_loop.running = True  # Start emitting rays
        bulb_info_label.visible = True  # Show bulb info
        update_bulb_info()  # Update the information displayed
    else:
        bulb_toggle_btn.text = 'Show Rays'
        bulb_toggle_btn.background = color.red
        emit_rays_loop.running = False  # Stop emitting rays
        bulb_info_label.visible = False  # Hide the bulb info


    update_bulb_info()
# Create Button
bulb_toggle_btn = button(text='Show Rays', bind=lambda _: toggle_rays(), background=color.red)

# Create a label to show bulb information
bulb_info_label = label(text='bulb_info', pos=vector(0, 5.3, 0), height=40, visible=False)

# Emit Rays Continuously When Button is Active
def emit_rays_loop():
    while True:
        if not emit_rays_loop.running:
            sleep(0.1)  # Prevent excessive CPU usage while stopped
            continue
        for c in bulb_rays.ray_colors:
            bulb.color = c
            bulb_rays.emit_rays(bulb.color)  # Emit rays based on the bulb color
            sleep(1)  # Change color every second

emit_rays_loop.running = False  # Start with rays disabled

# Run the Loop in the Background
import threading
threading.Thread(target=emit_rays_loop, daemon=True).start()

# Start Bulb Color Change in a Thread
threading.Thread(target=change_bulb_color, daemon=True).start()

# Start threads for each simulation
microwave_thread = Thread(target=microwave_simulation())
flame_thread = Thread(target=flame_simulation_loop)
vlc_thread = Thread(target=vlc_protocol.initialize_vlc_communication())

# Start the threads
microwave_thread.start()
flame_thread.start()

# Keep the simulation open
while True:
    rate(60)  # Runs at 60 frames per second


