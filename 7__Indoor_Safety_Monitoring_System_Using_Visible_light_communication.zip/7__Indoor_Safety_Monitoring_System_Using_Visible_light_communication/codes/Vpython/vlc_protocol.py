import time
import threading
import random
from queue import Queue

# Define the information to be transmitted
refrigerator_data = {
    "temperature": "2°C",
    "humidity": "45%",
    "power_consumption": "150W",
    "compressor_status": "Running",
    "door_status": "Closed",
    "cooling_efficiency": "Optimal",
    "maintenance_alerts": "None",
    "operating_mode": "Energy Saving",
    "error_codes": "No Errors",
    "carbon_footprint": "Low",
}

# Encoding function
def encode_data(data_dict):
    """Encodes refrigerator data into a binary-like string for transmission."""
    encoded_data = ""
    for key, value in data_dict.items():
        encoded_data += f"{key}:{value};"
    return encoded_data

# Decoding function
def decode_data(encoded_data):
    """Decodes the binary-like string back into a dictionary."""
    decoded_dict = {}
    items = encoded_data.split(";")
    for item in items:
        if item:
            key, value = item.split(":")
            decoded_dict[key] = value
    return decoded_dict

# Refrigerator transmitter
def refrigerator_transmitter(data_dict, transmission_queue):
    """Simulates a refrigerator transmitting data through VLC."""
    while True:
        encoded_data = encode_data(data_dict)
        transmission_queue.put(encoded_data)  # Put encoded data in the queue
        time.sleep(1)  # Simulate a delay between transmissions

# Transceiver receiver and display logic
def transceiver_receiver(transmission_queue):
    """Simulates a transceiver receiving and displaying VLC data."""
    while True:
        if not transmission_queue.empty():
            encoded_data = transmission_queue.get()  # Get data from the queue
            decoded_data = decode_data(encoded_data)
            display_transceiver_data(decoded_data)

# Display function for the transceiver
def display_transceiver_data(data_dict):
    """Displays the decoded refrigerator data in real time."""
    print("\nReceived Refrigerator Data:")
    for key, value in data_dict.items():
        print(f"{key}: {value}")

# Dynamic data simulation
def update_refrigerator_data():
    """Simulates dynamic changes in refrigerator data over time."""
    while True:
        refrigerator_data["temperature"] = f"{random.randint(1, 4)}°C"
        refrigerator_data["humidity"] = f"{random.randint(40, 50)}%"
        refrigerator_data["power_consumption"] = f"{random.randint(140, 160)}W"
        refrigerator_data["compressor_status"] = random.choice(["Running", "Idle"])
        refrigerator_data["door_status"] = random.choice(["Closed", "Open"])
        time.sleep(5)  # Update data every 5 seconds

def initialize_vlc_communication():

        # Queue to simulate the VLC communication channel
    transmission_queue = Queue()

    # Start the refrigerator transmitter thread
    transmitter_thread = threading.Thread(target=refrigerator_transmitter, args=(refrigerator_data, transmission_queue))
    transmitter_thread.daemon = True
    transmitter_thread.start()

    # Start the transceiver receiver thread
    receiver_thread = threading.Thread(target=transceiver_receiver, args=(transmission_queue,))
    receiver_thread.daemon = True
    receiver_thread.start()

    # Start the dynamic data update thread
    data_update_thread = threading.Thread(target=update_refrigerator_data)
    data_update_thread.daemon = True
    data_update_thread.start()

    print("VLC communication initialized. Receiving data...")
    while True:
        time.sleep(1)

