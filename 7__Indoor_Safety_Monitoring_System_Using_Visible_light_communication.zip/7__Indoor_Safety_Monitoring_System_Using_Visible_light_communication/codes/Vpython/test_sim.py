from vpython import *
import ray_behavior

# Scene setup
scene = canvas(title="Light Ray Simulation", width=800, height=600, background=color.black)

# TV and Transreceiver
tv = box(pos=vector(-5, 0, 0), size=vector(1, 2, 2), color=color.black)
transreceiver = sphere(pos=vector(5, 0, 0), radius=0.5, color=color.green)
wall = box(pos=vector(0, 0, 0), size=vector(0.5, 3, 3), color=color.gray(0.5))

# Button toggle logic
light_on = False

def toggle_light(evt):
    global light_on
    light_on = not light_on
    toggle_btn.text = "Turn Off Light" if light_on else "Turn On Light"

toggle_btn = button(bind=toggle_light, text="Turn On Light", background=color.red)

# Main simulation loop
rays = []
while True:
    rate(50)
    if light_on:
        if not rays:
            rays = ray_behavior.emit_light(tv.pos)  # Generate rays from TV
        rays = ray_behavior.update_rays(rays, transreceiver.pos, transreceiver.radius, wall)
    else:
        rays.clear()
