from vpython import *
from time import sleep  # For timed intervals
from time import time
from random import uniform
from threading import Thread

# Create the canvas with a diagonal view
canvas = canvas(width=800, height=600, background=color.white, title="Room Simulation")
canvas.camera.pos = vector(5, 5, 15)
canvas.camera.axis = vector(-5, -5, -15)

# Define a bigger room (walls, floor, ceiling)
floor = box(pos=vector(0, -0.05, 0), size=vector(15, 0.1, 15), color=color.gray(0.5))
left_wall = box(pos=vector(-7.5, 2.5, 0), size=vector(0.1, 5, 15), color=color.blue)
right_wall = box(pos=vector(7.5, 2.5, 0), size=vector(0.1, 5, 15), color=color.red)
back_wall = box(pos=vector(0, 2.5, -7.5), size=vector(15, 5, 0.1), color=color.green)

# Add objects in the room
# Refrigerator
refrigerator = box(pos=vector(-6, 1, 6), size=vector(1, 2, 1), color=color.cyan)

# Microwave
microwave = box(pos=vector(-4, 1, 6), size=vector(1.2, 0.8, 1), color=color.yellow)
# Transceiver position
transceiver = sphere(pos=vector(4, 1, 6), radius=0.5, color=color.red)

# Light rays from microwave to transceiver (initially invisible)
light_rays = []


# Timer variables
microwave_timer = 60  # Start time in seconds
microwave_on = False  # Track whether the microwave is on
timer_done_label = None  # To hold the "Timer Done" label
show_timer_done = False  # Track whether the label is visible
timer_start_time = 0  # For tracking time elapsed

# Timer label for displaying countdown
timer_label = label(pos=vector(4, 2.5, 1), text='', visible=False)

# Function to toggle the microwave on/off
def toggle_microwave(evt):
    global microwave_on, microwave_timer, timer_done_label, timer_start_time, show_timer_done, light_rays
    if microwave_on:  # Turn off
        microwave_on = False
        timer_label.visible = False  # Hide the timer
        # Hide the rays
        for ray in light_rays:
            ray.visible = False
        if timer_done_label:
            timer_done_label.visible = False  # Hide "Timer Done" if still visible
    else:  # Turn on
        microwave_on = True
        # Create rays from microwave to transceiver
        light_rays = []
        for i in range(5):  # Create 5 rays for simulation
            ray = arrow(pos=microwave.pos, axis=transceiver.pos - microwave.pos,
                        color=color.yellow, shaftwidth=0.05, visible=True)
            light_rays.append(ray)
        microwave_timer = 60  # Reset timer to 60 seconds
        timer_label.visible = True
        timer_done_label = None  # Reset the "Timer Done" label
        show_timer_done = False
        timer_start_time = time()  # Record the start time

# Microwave button
microwave_button = button(bind=toggle_microwave, text="Microwave Off", background=color.red)

# Simulation loop for microwave
def microwave_simulation():
    global microwave_timer, microwave_on, timer_done_label, show_timer_done, timer_start_time

    try:
        # Handle microwave countdown when it's on
        if microwave_on:
            elapsed_time = time() - timer_start_time
            microwave_timer = max(0, 60 - int(elapsed_time))  # Update the timer

            timer_label.text = f"Time Left: {microwave_timer} sec"

            if microwave_timer == 0 and not show_timer_done:
                # Timer has completed
                timer_done_label = label(pos=vector(4, 3, 1), text="Timer Done", height=16, color=color.red)
                show_timer_done = True
                timer_start_time = time()  # Reset start time for hiding label after 1 minute

            if show_timer_done and time() - timer_start_time >= 60:  # Hide "Timer Done" after 1 minute
                timer_done_label.visible = False
                show_timer_done = False
        else:
            microwave_button.text = "Microwave Off"
            microwave_button.background = color.red
        microwave_button.text = "Microwave On" if microwave_on else "Microwave Off"
        microwave_button.background = color.green if microwave_on else color.red

    except Exception as e:
        print(f"error: {e}")

# Start the simulation loop
while True:
    microwave_simulation()  # Call the microwave simulation to update the timer
    rate(60)  # Control the simulation rate
