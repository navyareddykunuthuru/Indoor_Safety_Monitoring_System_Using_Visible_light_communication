from vpython import curve, color, vector
import numpy as np

def emit_light(source_pos, num_rays=50, angle_spread=np.pi / 6):
    """
    Generate rays from a source position.

    Args:
        source_pos (vector): The starting position of the light source.
        num_rays (int): Number of rays to emit.
        angle_spread (float): Angle spread of the rays in radians.

    Returns:
        list: A list of dictionaries, each containing a ray object, its direction, and position.
    """
    rays = []
    for _ in range(num_rays):
        angle = np.random.uniform(-angle_spread, angle_spread)  # Random angle for scattering
        direction = vector(np.cos(angle), np.sin(angle), 0)
        ray = curve(color=color.yellow, radius=0.02)
        rays.append({"curve": ray, "direction": direction, "position": source_pos})
    return rays

def update_rays(rays, target_pos, target_radius, wall=None):
    """
    Update ray positions and simulate interactions.

    Args:
        rays (list): List of rays with their properties.
        target_pos (vector): Position of the target (e.g., transreceiver).
        target_radius (float): Radius of the target for hit detection.
        wall (box, optional): Wall object for reflection handling.

    Returns:
        list: Updated list of rays (removes rays that hit the target).
    """
    for ray in rays[:]:  # Iterate over a copy of the list to allow removal
        ray_curve = ray["curve"]
        direction = ray["direction"]
        position = ray["position"]

        # Extend the ray forward
        new_position = position + direction * 0.1

        # Check for interaction with wall (if specified)
        if wall and wall.pos.x - wall.size.x / 2 < new_position.x < wall.pos.x + wall.size.x / 2 and \
            wall.pos.y - wall.size.y / 2 < new_position.y < wall.pos.y + wall.size.y / 2:
            direction.x = -direction.x  # Reflect the ray
            ray["direction"] = direction

        # Update ray's position
        ray_curve.append(pos=new_position)
        ray["position"] = new_position

        # Stop ray if it reaches the target
        if (new_position - target_pos).mag < target_radius:
            ray_curve.color = color.green  # Ray reaches the target
            rays.remove(ray)

    return rays
