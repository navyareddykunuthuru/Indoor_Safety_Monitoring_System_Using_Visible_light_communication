from vpython import *
from random import uniform

class BulbRays:
    def __init__(self, bulb, receiver):
        self.bulb = bulb
        self.receiver = receiver
        self.intensity = 1.0  # Default intensity (max: 1.0, min: 0.1)
        self.ray_colors = [color.red, color.yellow, color.blue]  # Match bulb colors
    def emit_rays(self, bulb_color):
        """
               Emits a single ray from the bulb to the receiver based on intensity and color.
               The ray is emitted in a random direction but always pointing towards the receiver.
        """
        # Calculate a random direction vector pointing towards the receiver
        dir_to_receiver = self.receiver.pos - self.bulb.pos  # Vector from bulb to receiver
        random_offset = vector(uniform(-0.2, 0.2), uniform(-0.2, 0.2),
                               uniform(-0.2, 0.2))  # Small random perturbation
        ray_direction = dir_to_receiver + random_offset  # Add random perturbation to the direction

        # Normalize the ray direction
        ray_direction = norm(ray_direction)

        # Create the ray curve
        ray = curve(color=bulb_color, radius=0.02 * self.intensity)  # Ray width scales with intensity
        ray.append(pos=self.bulb.pos)
        ray.append(pos=self.bulb.pos + ray_direction * 5)  # Emit ray in the direction towards the receiver

        sleep(2)  # Wait a moment to let each ray be visible
        ray.visible = False  # Remove ray after displaying briefly
    def set_intensity(self, intensity):
        """
        Sets the intensity of the rays (value between 0.1 and 1.0).
        """
        self.intensity = max(0.1, min(1.0, intensity))  # Clamp intensity to range [0.1, 1.0]
